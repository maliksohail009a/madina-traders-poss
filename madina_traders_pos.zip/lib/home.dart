import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Madina Traders POS')),
      body: GridView.count(
        crossAxisCount: 2,
        children: [
          Card(child: Center(child: Text('New Bill'))),
          Card(child: Center(child: Text('Items'))),
          Card(child: Center(child: Text('Customers'))),
          Card(child: Center(child: Text('Reports'))),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'home.dart';

class LoginPage extends StatelessWidget {
  final user = TextEditingController();
  final pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('MADINA TRADERS'),
              TextField(controller: user),
              TextField(controller: pass),
              ElevatedButton(
                onPressed: () {
                  if (user.text == 'admin' && pass.text == '1234') {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => HomePage()));
                  }
                },
                child: Text('LOGIN'),
              )
            ],
          ),
        ),
      ),
    );
  }
}